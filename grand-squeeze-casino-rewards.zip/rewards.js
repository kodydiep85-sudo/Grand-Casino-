/* Grand Squeeze Casino — Rewards Edition.
   Everyone starts with $5,000. More chips come from the daily reward, each game's daily challenges and comeback chips.
   Every game has its own three challenges each day, and they only count while you play that game.
   Progress is counted by watching each game's win/loss total after every hand; rewards are claimed on the
   game menu, so money is never added while a table is in play. */
(function(){
  'use strict';
  var START=5000, DAILY=[500,750,1000,1500,2000,3000,5000], GAMEBONUS=500, RERUN=2500, OUT=10;
  var GAMES={baccarat:'Baccarat',holdem:"Texas Hold'em",tcp:'Three Card Poker',bj:'Blackjack',pg:'Pai Gow',craps:'Craps'};
  var ORDER=['baccarat','holdem','tcp','bj','pg','craps'];
  var UNIT={baccarat:'hands',holdem:'hands',tcp:'hands',bj:'hands',pg:'hands',craps:'rolls'},ONE={craps:'roll'};
  /* what each game's challenges can ask for: [type, choices of target, matching rewards] */
  var POOL={
    baccarat:[['play',[12,18,25],[250,350,500]],['win',[5,8,12],[350,500,750]],['streak',[3,4],[500,800]],['big',[200,500],[400,700]],['profit',[400,1000],[450,800]]],
    holdem:[['play',[8,12,16],[250,350,500]],['win',[3,5,7],[350,500,750]],['streak',[2,3],[450,800]],['big',[100,300],[400,700]],['profit',[200,600],[450,800]]],
    tcp:[['play',[10,15,20],[250,350,500]],['win',[4,6,9],[350,500,750]],['streak',[3,4],[500,850]],['big',[60,150],[400,700]],['profit',[150,400],[450,800]]],
    bj:[['play',[12,18,25],[250,350,500]],['win',[5,8,12],[350,500,750]],['streak',[3,4],[500,850]],['big',[50,150],[400,700]],['profit',[200,500],[450,800]]],
    pg:[['play',[10,15,20],[250,350,500]],['win',[3,5,7],[350,500,750]],['streak',[2,3],[450,800]],['big',[50,150],[400,700]],['profit',[100,300],[450,800]]],
    craps:[['play',[20,30,45],[250,350,500]],['win',[6,10,15],[350,500,750]],['streak',[3,4],[450,800]],['big',[100,400],[400,750]],['profit',[300,900],[450,900]]]
  };
  /* every day, Blackjack always has a "win this many hands" challenge and Baccarat always has "win 3 in a row" */
  var MUST={bj:['win',[5,8,12],[350,500,750]],baccarat:['streak',[3],[600]]};
  var LS=window.localStorage, rawGet=Storage.prototype.getItem, rawSet=Storage.prototype.setItem;
  function get(k){try{return rawGet.call(LS,k)}catch(e){return null}}
  function put(k,v){try{rawSet.call(LS,k,String(v))}catch(e){}}
  function slug(n){return String(n||'Player').trim().toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,20)||'player'}
  function who(){try{return sessionStorage.getItem('gs.me')||LS.getItem('gs.name')||'Player'}catch(e){return 'Player'}}
  function key(k){return 'gs.'+k+'@'+slug(who())}
  function pad(n){return (n<10?'0':'')+n}
  function day(off){var d=new Date();d.setDate(d.getDate()+(off||0));return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())}
  function money(n){return '$'+Math.floor(n).toLocaleString('en-US')}
  function load(){try{return JSON.parse(get(key('rw'))||'null')||{}}catch(e){return {}}}
  function save(d){put(key('rw'),JSON.stringify(d))}
  function wallet(){var w=get(key('wallet')),n=Number(w);return w!==null&&isFinite(n)&&n>=0?n:START}
  function credit(a){put(key('wallet'),Math.floor(wallet()+a));put(key('walletAt'),Date.now());try{dispatchEvent(new Event('gs:wallet'))}catch(e){}}

  /* ---------- each game's three challenges for today, the same all day for each player ---------- */
  function rng(seed){var h=2166136261;for(var i=0;i<seed.length;i++){h^=seed.charCodeAt(i);h=Math.imul(h,16777619)}
    return function(){h+=0x6D2B79F5;var t=h;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return ((t^t>>>14)>>>0)/4294967296}}
  function make(g,seed){
    var r=rng(seed+'|'+g),pool=POOL[g].slice(),out=[];
    // always one "play" challenge, then this game's must-have one (if it has one), then others to make three
    var first=pool.shift(),must=MUST[g],picks=[first];
    if(must)picks.push(must);
    pool=pool.filter(function(t){return !must||t[0]!==must[0]});pool.sort(function(){return r()-.5});
    while(picks.length<3)picks.push(pool.shift());
    picks.forEach(function(t){var i=Math.floor(r()*t[1].length);out.push({t:t[0],n:t[1][i],r:t[2][i],p:0,claimed:false,told:false})});
    // you play more hands than you win: keep the "play" target above any "win" target
    var pl=out.filter(function(c){return c.t==='play'})[0],wn=out.filter(function(c){return c.t==='win'||c.t==='streak'}).sort(function(a,b){return b.n-a.n})[0];
    if(pl&&wn&&wn.n*1.6>pl.n)pl.n=Math.ceil(wn.n*2/5)*5;
    return {list:out,bonus:false,run:0};
  }
  function label(c,g){
    var u=UNIT[g];
    return c.t==='play'?'Play '+c.n+' '+u:c.t==='win'?'Win '+c.n+' '+u:c.t==='streak'?'Win '+c.n+' '+u+' in a row':
      c.t==='big'?'Win '+money(c.n)+'+ on a single '+(ONE[g]||'hand'):'Win '+money(c.n)+' in total today';
  }
  function today(d){
    d=d||load();var t=day();
    if(!d.cg||d.cg.date!==t||d.cg.v!==3){d.cg={date:t,v:3,games:{}};ORDER.forEach(function(g){d.cg.games[g]=make(g,t+'|'+slug(who()))});delete d.ch;save(d)}
    return d;
  }

  /* ---------- counting: every game adds each hand's result to your win/loss total ---------- */
  var page=(location.pathname.split('/').pop()||'').replace('.html','');
  function onHand(delta){
    var d=today(),G=d.cg.games[page],news=[];if(!G)return;
    if(delta>0)G.run=(G.run||0)+1;else if(delta<0)G.run=0;   // a push doesn't break a winning run
    G.list.forEach(function(c){
      if(c.p>=c.n)return;
      if(c.t==='play')c.p++;
      else if(c.t==='win'&&delta>0)c.p++;
      else if(c.t==='streak')c.p=Math.max(c.p,G.run);
      else if(c.t==='big'&&delta>=c.n)c.p=c.n;
      else if(c.t==='profit'&&delta>0)c.p+=delta;
      c.p=Math.min(c.p,c.n);
      if(c.p>=c.n&&!c.told){c.told=true;news.push(c)}
    });
    save(d);news.forEach(function(c){toast('Challenge complete: '+label(c,page)+'. Claim '+money(c.r)+' on the game menu.')});
    panel();
  }
  if(GAMES[page]){
    Storage.prototype.setItem=function(k,v){
      if(this===LS&&k===key('profit')){
        var old=Number(rawGet.call(LS,k))||0;rawSet.call(this,k,v);
        try{onHand(Math.round((Number(v)-old)*100)/100)}catch(e){}
        return;
      }
      if(this===LS&&k===key('wallet')){rawSet.call(this,k,v);if(Number(v)<OUT)setTimeout(broke,1600);return}
      return rawSet.call(this,k,v);
    };
  }

  /* ---------- notices and styles shared by the menu and the tables ---------- */
  function toast(text){
    var t=document.createElement('div');t.className='rwtoast';t.setAttribute('role','status');t.innerHTML='<b>🎁</b><span></span>';t.lastChild.textContent=text;
    document.body.appendChild(t);requestAnimationFrame(function(){t.classList.add('show')});
    setTimeout(function(){t.classList.remove('show');setTimeout(function(){t.remove()},400)},5200);
  }
  var css=document.createElement('style');css.textContent=
   '.rwtoast{position:fixed;left:50%;top:14px;z-index:90;display:flex;gap:10px;align-items:center;max-width:min(560px,92vw);padding:11px 16px;border-radius:12px;'+
   'background:linear-gradient(#1f1a10,#0a0806);border:1px solid #e9c46a;box-shadow:0 14px 34px #000c;color:#f6e7c8;font:600 .9rem system-ui,sans-serif;line-height:1.35;'+
   'transform:translate(-50%,-140%);transition:transform .35s cubic-bezier(.2,.8,.3,1)}.rwtoast.show{transform:translate(-50%,0)}.rwtoast b{font-size:1.3rem}'+
   '.rwgo{background:linear-gradient(#f6d77a,#c7962c)!important;border-color:#ffe9a8!important;color:#241600!important}'+
   '.rwpanel{display:grid;gap:6px;padding:10px 12px;border-radius:12px;background:linear-gradient(#16130fe6,#070605f0);border:1px solid #c9a24a88;color:#f6e7c8;font:600 .78rem system-ui,sans-serif}'+
   '.rwpanel h4{margin:0;display:flex;justify-content:space-between;font:700 .7rem Georgia,serif;letter-spacing:.16em;color:#e9c46a}.rwpanel h4 a{color:#9cf0b8;font:600 .7rem system-ui;letter-spacing:0;text-decoration:none}'+
   '.rwpanel .row{display:grid;grid-template-columns:1fr auto;gap:2px 8px;align-items:center}.rwpanel .row small{color:#cdbf9a;font-variant-numeric:tabular-nums}'+
   '.rwpanel .bar{grid-column:1/-1;height:5px;border-radius:9px;background:#ffffff14;overflow:hidden}.rwpanel .bar i{display:block;height:100%;background:linear-gradient(90deg,#c7962c,#ffe08a)}'+
   '.rwbroke{position:fixed;inset:0;z-index:95;display:grid;place-items:center;padding:16px;background:#000c}'+
   '.rwbcard{width:min(100%,440px);display:grid;gap:10px;padding:20px;border-radius:16px;background:linear-gradient(160deg,#1a1210,#070505);border:2px solid #e9c46a;box-shadow:0 30px 70px #000;text-align:center;color:#f6e7c8;font:500 .95rem system-ui,sans-serif}'+
   '.rwbcard h3{margin:0;font:700 1.2rem Georgia,serif;letter-spacing:.2em;color:#e9c46a}.rwbcard p{margin:0;color:#e6dcc0}'+
   '.rwbcard button{padding:12px;border-radius:10px;border:1px solid #c9a24a;background:linear-gradient(#2a2630,#121016);color:#f6e7c8;font:700 .85rem Georgia,serif;letter-spacing:.06em;cursor:pointer}'+
   '.rwbcard button.go{background:linear-gradient(#f6d77a,#c7962c 55%,#a8792a);border-color:#fff0b8;color:#241600}'+
   '.rwpanel .row.done .bar i{background:linear-gradient(90deg,#3fd18a,#9cf0b8)}.rwpanel .row.done small{color:#9cf0b8}';
  document.head.appendChild(css);
  function prog(c){return c.t==='big'||c.t==='profit'?money(c.p)+' / '+money(c.n):c.p+' / '+c.n}


  /* ---------- run out of chips and you get $2,500 to try to run it back up.
     Once per day. "Out" means you can't cover a $10 bet (chips riding on a bet still count). ---------- */
  function isOut(){return wallet()<OUT}
  function rerunLeft(){return load().rerunDay!==day()}   // once per day
  function takeRerun(){if(!isOut())return 0;var d=load();if(d.rerunDay===day())return 0;d.rerunDay=day();save(d);credit(RERUN);return RERUN}
  var brokeShown=false;
  function broke(){
    if(brokeShown||!isOut()||!GAMES[page])return;brokeShown=true;
    var m=document.createElement('div');m.className='rwbroke';m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');
    m.innerHTML='<div class="rwbcard"><h3>OUT OF CHIPS</h3>'+(rerunLeft()?'<p>Here\'s '+money(RERUN)+' to try to run it back up. You get this once a day.</p><button class="go" data-a="go">Take '+money(RERUN)+' & keep playing</button>':
      '<p>You\'ve used today\'s '+money(RERUN)+' run-it-up. You get another one in '+left()+'. Until then, earn chips with your daily reward and today\'s challenges.</p><button class="go" data-a="menu">Daily reward & challenges</button><button data-a="x">Close</button>')+'</div>';
    document.body.appendChild(m);
    m.addEventListener('click',function(e){var a=e.target.dataset&&e.target.dataset.a;if(a==='x'){m.remove();return}if(a==='menu'){location.href='index.html#rewards';return}if(a!=='go')return;
      var got=takeRerun();if(!got){m.remove();return}
      // the table reads your chips when it opens: go back to your own table with them
      try{['gs.uthCode','gs.tcpCode','gs.bjCode','gs.pgCode','gs.crapsCode','gs.lastCode'].forEach(function(k){sessionStorage.removeItem(k)})}catch(err){}
      e.target.textContent='+'+money(got)+' · back to the table…';setTimeout(function(){location.reload()},700)});
  }

  /* ---------- on a table: this game's challenges, and no way to buy chips ---------- */
  function panel(){
    var el=document.getElementById('rwPanel');if(!el)return;
    var G=today().cg.games[page];if(!G)return;
    var done=G.list.filter(function(c){return c.p>=c.n}).length;
    el.innerHTML='<h4>'+GAMES[page].toUpperCase()+' CHALLENGES <a href="index.html#rewards">'+done+'/3 · claim on menu</a></h4>'+
      G.list.map(function(c){var pct=Math.round(c.p/c.n*100),fin=c.p>=c.n;
        return '<div class="row'+(fin?' done':'')+'"><span>'+label(c,page)+'</span><small>'+(c.claimed?'✓ claimed':fin?'✓ '+money(c.r):prog(c)+' · '+money(c.r))+'</small><span class="bar"><i style="width:'+pct+'%"></i></span></div>'}).join('');
  }
  function tablePage(){
    ['buyBtn','changeBtn','resetBtn'].forEach(function(id){var b=document.getElementById(id);if(b)b.hidden=true});   // no buying chips here (and nothing extra beside Deal)
    var tb=document.getElementById('topBtn');if(tb){tb.textContent='🎁 Rewards & daily bonus';tb.classList.add('rwgo');
      tb.onclick=function(e){e.preventDefault();location.href='index.html#rewards'}}
    var host=document.querySelector('.infocol')||document.querySelector('.side');
    if(host&&!document.getElementById('rwPanel')){var p=document.createElement('div');p.id='rwPanel';p.className='rwpanel';
      var status=host.querySelector('.status');if(status&&status.nextSibling)host.insertBefore(p,status.nextSibling);else host.appendChild(p)}
    panel();
    if(isOut())setTimeout(broke,1200);
  }

  /* ---------- the rewards panel on the game menu ---------- */
  function left(){var n=new Date(),m=new Date(n.getFullYear(),n.getMonth(),n.getDate()+1),s=Math.max(0,m-n),h=Math.floor(s/3600e3),mm=Math.floor(s%3600e3/60e3);return h+'h '+pad(mm)+'m'}
  function streakNow(d){var dl=d.daily||{};return dl.last===day()?dl.streak:dl.last===day(-1)?dl.streak:0}
  var tab=null;try{tab=sessionStorage.getItem('gs.rwTab')}catch(e){}
  function render(){
    var el=document.getElementById('rewards');if(!el)return;
    var d=today(),dl=d.daily||{},claimedToday=dl.last===day(),st=streakNow(d),next=claimedToday?st:st+1,idx=(next-1)%7,w=wallet();
    var dots='';for(var i=0;i<7;i++){var cyc=Math.floor((next-1)/7)*7,dn=cyc+i+1,got=dn<next||(dn===next&&claimedToday),now=dn===next&&!claimedToday;
      dots+='<li class="'+(got?'got':'')+(now?' now':'')+'"><small>DAY '+(i+1)+'</small><b>'+money(DAILY[i])+'</b></li>'}
    // pick a tab: the one you chose, otherwise a game with something to claim
    var G=d.cg.games;if(!tab||!G[tab])tab=ORDER.find(function(g){return G[g].list.some(function(c){return c.p>=c.n&&!c.claimed})})||'baccarat';
    var tabs=ORDER.map(function(g){var L=G[g].list,dn=L.filter(function(c){return c.p>=c.n}).length,ready=L.some(function(c){return c.p>=c.n&&!c.claimed})||(dn===3&&!G[g].bonus&&L.every(function(c){return c.claimed}));
      return '<button class="rwtab'+(g===tab?' on':'')+(ready?' ready':'')+'" data-tab="'+g+'">'+GAMES[g]+'<i>'+dn+'/3</i></button>'}).join('');
    var cur=G[tab],list=cur.list.map(function(c,i){var done=c.p>=c.n,pct=Math.round(c.p/c.n*100);
      return '<li class="'+(c.claimed?'claimed':done?'done':'')+'"><div class="rwtx"><b>'+label(c,tab)+'</b><span class="rwbar"><i style="width:'+pct+'%"></i></span><small>'+prog(c)+'</small></div>'+
        (c.claimed?'<em>✓ '+money(c.r)+'</em>':done?'<button data-ch="'+i+'">Claim '+money(c.r)+'</button>':'<em class="todo">'+money(c.r)+'</em>')+'</li>'}).join('');
    var all=cur.list.every(function(c){return c.claimed});
    el.innerHTML='<div class="rwcard daily"><h3>DAILY REWARD <span>'+(st?'🔥 '+st+'-day streak':'Start a streak')+'</span></h3><ol class="rwdays">'+dots+'</ol>'+
      (claimedToday?'<button disabled>Claimed · next in '+left()+'</button>':'<button id="rwDaily" class="big">Claim '+money(DAILY[idx])+'</button>')+
      (isOut()?(rerunLeft()?'<button id="rwBack" class="back2">Out of chips? Take '+money(RERUN)+' to run it back up (once a day)</button>':'<p class="rwnote">Out of chips: today\'s '+money(RERUN)+' is used. The next one is in '+left()+'. Claim your daily reward or finish challenges to keep playing.</p>'):'')+
      '</div><div class="rwcard chal"><h3>TODAY\'S CHALLENGES <span>each game has its own · new ones in '+left()+'</span></h3><div class="rwtabs">'+tabs+'</div><ul class="rwlist">'+list+'</ul>'+
      '<p class="rwbonus'+(cur.bonus?' got':'')+'">'+(cur.bonus?'✓ '+GAMES[tab]+' bonus claimed: '+money(GAMEBONUS):all?'<button id="rwAll">Claim the '+money(GAMEBONUS)+' '+GAMES[tab]+' bonus</button>':'Finish all three '+GAMES[tab]+' challenges for a '+money(GAMEBONUS)+' bonus. They count while you play '+GAMES[tab]+'.')+'</p></div>';
    var b=document.getElementById('rwDaily');if(b)b.onclick=function(){var d=today(),s=streakNow(d),n=(d.daily&&d.daily.last===day(-1))?s+1:1;
      if(d.daily&&d.daily.last===day())return;var amt=DAILY[(n-1)%7];d.daily={last:day(),streak:n};save(d);credit(amt);render();flash('+'+money(amt)+' daily reward')};
    b=document.getElementById('rwBack');if(b)b.onclick=function(){var got=takeRerun();if(got){render();flash('+'+money(got)+' · run it up')}};
    b=document.getElementById('rwAll');if(b)b.onclick=function(){var d=today(),g=d.cg.games[tab];if(g.bonus||!g.list.every(function(c){return c.claimed}))return;g.bonus=true;save(d);credit(GAMEBONUS);render();flash('+'+money(GAMEBONUS)+' '+GAMES[tab]+' bonus')};
    el.querySelectorAll('[data-ch]').forEach(function(x){x.onclick=function(){var d=today(),c=d.cg.games[tab].list[+x.dataset.ch];if(!c||c.claimed||c.p<c.n)return;c.claimed=true;save(d);credit(c.r);render();flash('+'+money(c.r)+' challenge reward')}});
    el.querySelectorAll('[data-tab]').forEach(function(x){x.onclick=function(){tab=x.dataset.tab;try{sessionStorage.setItem('gs.rwTab',tab)}catch(e){}render()}});
  }
  function flash(t){var f=document.createElement('div');f.className='rwflash';f.textContent=t;document.body.appendChild(f);setTimeout(function(){f.remove()},1800)}

  render();if(GAMES[page])tablePage();   // loaded with defer: the page and its own script are ready
  addEventListener('pageshow',function(){render();panel()});
  setInterval(function(){render();panel()},60000);
  document.addEventListener('input',function(e){if(e.target&&e.target.id==='nameIn')setTimeout(render,0)});
  window.GSRewards={render:render};
})();
